﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task2_loops;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task2_loops
{
    internal class RealtimeForTracking
    {
            public static void TrackParcel()
            {
                string[] trackingStatus = { "Dispatched", "In Transit", "Arrived at Hub", "Out for Delivery", "Delivered" };
                int index = 0;

                Console.WriteLine("Tracking Parcel Progress...");
                while (index < trackingStatus.Length) // Using a while loop
                {
                    Console.WriteLine($"Status: {trackingStatus[index]}");
                    index++;
                // to ensure real time tracking ,  have implemented the threading concepts
                    System.Threading.Thread.Sleep(1000); 
                }

                Console.WriteLine("Your parcel has been successfully delivered");
            }
        }
    }

