﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow
{
    internal class OrderStatusChecker
    {
        public class OrderStatus
        {
            public static void CheckOrderStatus(string status)
            {
                //mainly we should consider the 3 thing here 1.process, 2. deliver, 3. cancalled
                if (status == "Processing")
                    Console.WriteLine("Your order is being processed.");
                else if (status == "Delivered")
                    Console.WriteLine("Your order has been delivered.");
                else if (status == "Cancelled")
                    Console.WriteLine("Your order has been cancelled.");
                else
                    Console.WriteLine("Invalid status.");
            }
        }
    }
}


