﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions
{

    internal class OrderConfirmation
    {
       
            private static Dictionary<int, string> orders = new Dictionary<int, string>();

            public static void AddOrder(int orderId, string details)
            {
                orders[orderId] = details;
                Console.WriteLine($"Order {orderId} added.");
            }

            public static void GetOrder(int orderId)
            {
                if (orders.ContainsKey(orderId))
                    Console.WriteLine($"Order {orderId}: {orders[orderId]}");
                else
                    Console.WriteLine($"Order {orderId} not found.");
            }
            public static void GenerateEmail()
            {
                Console.WriteLine("\nGenerating order confirmation email...");
                Console.WriteLine("Subject: Order Confirmation");
                Console.WriteLine("Dear Customer,");
                Console.WriteLine("Thank you for your order... Your order has been successfully placed.");
                Console.WriteLine("We will notify you once your package is shipped.");
                Console.WriteLine("Always welcome,\nCourier Management System");
            }
        }
    }


