﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions
{
    internal class CustomerValidation
    {
        
        
            public static bool IsValidPhoneNumber(string phone)
            {
                return Regex.IsMatch(phone, @"^\d{10}$");
            }

            public static bool IsValidName(string name)
            {
                return !string.IsNullOrWhiteSpace(name) && name.Length >= 2;
            }

            public static bool IsValidAddress(string address)
            {
                return !string.IsNullOrWhiteSpace(address) && address.Length > 5;
            }

            public static bool Validate(string name, string address, string phone)
            {
                return IsValidName(name) && IsValidAddress(address) && IsValidPhoneNumber(phone);
            }
        }
    }