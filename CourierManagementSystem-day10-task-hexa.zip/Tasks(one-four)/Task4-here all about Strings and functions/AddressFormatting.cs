﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions
{
    internal class AddressFormatting
    {
        public static string Format(string input)
        {
            // Splitting the input based on commas
            string[] parts = input.Split(',');

            // Checking if the input has at least 4 parts (Street, City, State, Zip)
            if (parts.Length < 4)
            {
                return "Invalid address format. Please enter in 'Street, City, State, Zip' format.";
            }

            // Trim extra spaces and format correctly
            string street = parts[0].Trim();
            string city = parts[1].Trim();
            string state = parts[2].Trim();
            string zip = parts[3].Trim();

            return $"{street}, {city}, {state} - {zip}".ToUpper();
        }
    }
}