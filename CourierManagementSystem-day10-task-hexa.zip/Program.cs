﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using CourierManangementSystem_day10task_hexa.Entities;
using CourierManangementSystem_day10task_hexa.Services;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
                ICourierUserService userService = new CourierUserService();
                ICourierAdminService adminService = new CourierAdminService();

                while (true)
                {
                   
                    Console.WriteLine("welcome you all for courier management system");
                    Console.WriteLine("1. Place Order");
                    Console.WriteLine("2. Get Order Status");
                    Console.WriteLine("3. Cancel Order");
                    Console.WriteLine("4. View Assigned Orders");
                    Console.WriteLine("5. Add Courier Staff");
                    Console.WriteLine("6. Assign Couriers to Shipping");
                    Console.WriteLine("7. Parcel Tracking");
                    Console.WriteLine("8. Validate Customer Data");
                    Console.WriteLine("9. Format Address");
                    Console.WriteLine("10. Generate Order Confirmation Email");
                    Console.WriteLine("11. Calculate Shipping Cost");
                    Console.WriteLine("12. Generate Secure Password");
                    Console.WriteLine("13. Find Similar Addresses");
                    Console.WriteLine("14. Exit");
                    Console.Write("Enter your choice: ");

                    string choice = Console.ReadLine();
                    switch (choice)
                    {
                        case "1":
                            PlaceOrder(userService);
                            break;
                        case "2":
                            GetOrderStatus(userService);
                            break;
                        case "3":
                            CancelOrder(userService);
                            break;
                        case "4":
                            GetAssignedOrders(userService);
                            break;
                        case "5":
                            AddCourierStaff(adminService);
                            break;
                        case "6":
                            AssignCouriersToShipments();
                            break;
                        case "7":
                            ParcelTracking();
                            break;
                        case "8":
                            ValidateCustomerData();
                            break;
                        case "9":
                            FormatAddress();
                            break;
                        case "10":
                            GenerateOrderConfirmation();
                            break;
                        case "11":
                            CalculateShippingCost();
                            break;
                        case "12":
                            GenerateSecurePassword();
                            break;
                        case "13":
                            FindSimilarAddresses();
                            break;
                        case "14":
                            Console.WriteLine("you can exit.. Thank you");
                            return;
                        default:
                            Console.WriteLine("Invalid choice.. can youPlease try again.");
                            break;
                    }

                    Console.WriteLine("\n you can Press Enter to continue...");
                    Console.ReadLine();
                }
            }

            static void PlaceOrder(ICourierUserService userService)
            {
                Console.Write("Enter sender name: ");
                string senderName = Console.ReadLine();
                Console.Write("Enter sender address: ");
                string senderAddress = Console.ReadLine();
                Console.Write("Enter receiver name: ");
                string receiverName = Console.ReadLine();
                Console.Write("Enter receiver address: ");
                string receiverAddress = Console.ReadLine();
                Console.Write("Enter weight of the package: ");
                double weight = Convert.ToDouble(Console.ReadLine());

            Courier courier = new Courier(0, senderName, senderAddress, receiverName, receiverAddress, weight, "", DateTime.Now, 1);


            string trackingNumber = userService.PlaceOrder(courier);
                Console.WriteLine($"Order placed successfully! Tracking Number: {trackingNumber}");
            }

            static void GetOrderStatus(ICourierUserService userService)
            {
                Console.Write("Enter tracking number: ");
                string trackingNumber = Console.ReadLine();
                string status = userService.GetOrderStatus(trackingNumber);
                Console.WriteLine($"Order Status: {status}");
            }

            static void CancelOrder(ICourierUserService userService)
            {
                Console.Write("Enter tracking number to cancel: ");
                string trackingNumber = Console.ReadLine();
                bool isCancelled = userService.CancelOrder(trackingNumber);
                Console.WriteLine(isCancelled ? "Order successfully canceled!" : "Order cancellation failed.");
            }

            static void GetAssignedOrders(ICourierUserService userService)
            {
                Console.Write("Enter courier staff ID: ");
                int staffId = Convert.ToInt32(Console.ReadLine());
                List<Courier> orders = userService.GetAssignedOrders(staffId);
                foreach (var order in orders)
                {
                    Console.WriteLine(order);
                }
            }

            static void AddCourierStaff(ICourierAdminService adminService)
            {
                Console.Write("Enter staff name: ");
                string name = Console.ReadLine();
                Console.Write("Enter contact number: ");
                string contactNumber = Console.ReadLine();
            Employee newStaff = new Employee(name, contactNumber);
            int staffId = adminService.AddCourierStaff(newStaff);
                Console.WriteLine($"New Staff Added! Staff ID: {staffId}");
            }

        static void AssignCouriersToShipments()
        {
            List<string> availableCouriers = new List<string> { "Courier1", "Courier2", "Courier3" };
            string newOrder = "Order123";

            CourierAssignment.AssignCourier(availableCouriers, newOrder);
        }



        static void ParcelTracking()
        {
            ParcelTrackingHistory.ShowTrackingHistory();
        }


        static void ValidateCustomerData()
            {
                Console.Write("Enter name: ");
                string name = Console.ReadLine();
                Console.Write("Enter address: ");
                string address = Console.ReadLine();
                Console.Write("Enter phone number: ");
                string phone = Console.ReadLine();
                bool isValid = CustomerValidation.Validate(name, address, phone);
                Console.WriteLine(isValid ? "Valid data!" : "Invalid data!");
            }

            static void FormatAddress()
            {
                Console.Write("Enter Address (Street, City, State, Zip): ");
                string input = Console.ReadLine();
                string formattedAddress = AddressFormatting.Format(input);
                Console.WriteLine($"Formatted Address: {formattedAddress}");
            }

            static void GenerateOrderConfirmation()
            {
                OrderConfirmation.GenerateEmail();
            }

        static void CalculateShippingCost()
        {
            Console.Write("Enter package weight (kg): ");
            double weight = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter destination (Domestic/International): ");
            string destination = Console.ReadLine();

            double cost = ShippingCostCalculator.CalculateCost(weight, destination);
            Console.WriteLine($"Shipping Cost: ${cost}");
        }


        static void GenerateSecurePassword()
            {
            string password = PasswordGenerator.GeneratePassword(10); 
            Console.WriteLine($"Generated Secure Password: {password}");
            }

        static void FindSimilarAddresses()
        {
            Console.Write("Enter first address: ");
            string addr1 = Console.ReadLine();
            Console.Write("Enter second address: ");
            string addr2 = Console.ReadLine();

            bool isSimilar = FindSimilarAddress.AreAddressesSimilar(addr1, addr2);
            Console.WriteLine(isSimilar ? "Addresses are similar!" : "Addresses are different.");
        }

    }
}
