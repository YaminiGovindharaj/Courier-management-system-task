﻿using System;
using System.Collections.Generic;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Services
{
    public interface ICourierUserService
    {
        string PlaceOrder(Courier courierObj);
        string GetOrderStatus(string trackingNumber);
        bool CancelOrder(string trackingNumber);
        List<Courier> GetAssignedOrders(int courierStaffId);
    }
}
