﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Services
{
    
        public class CourierAdminService : ICourierAdminService 
        {
            private List<Employee> staffList = new List<Employee>(); 

            public int AddCourierStaff(Employee employee)
            {
                if (employee == null)
                {
                    throw new ArgumentNullException(nameof(employee), "Employee object cannot be null.");
                }

                staffList.Add(employee);
                return employee.EmployeeID; 
            }

            public bool RemoveCourierStaff(int employeeID)
            {
                return staffList.RemoveAll(e => e.EmployeeID == employeeID) > 0;
            }

            public List<Employee> GetAllCourierStaff()
            {
                return staffList;
            }
        }
    }



