﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Services
{
        public interface ICourierAdminService
        {
            int AddCourierStaff(Employee employee);
            bool RemoveCourierStaff(int employeeID);
            List<Employee> GetAllCourierStaff();
        }
    }



