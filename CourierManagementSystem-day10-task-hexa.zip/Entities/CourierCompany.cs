﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Entities
{
    internal class CourierCompany
    {
            public int CompanyID
        { get; set; }
            public string Name 
        { get; set; }
            public string Address 
        { get; set; }
            public string ContactNumber 
        { get; set; }
            public string Email 
        { get; set; }

            public CourierCompany()
        { }

            public CourierCompany(int companyID, string name, string address, string contactNumber, string email)
            {
                CompanyID = companyID;
                Name = name;
                Address = address;
                ContactNumber = contactNumber;
                Email = email;
            }

            public override string ToString()
            {
                return $"Company ID: {CompanyID}, Name: {Name}, Address: {Address}, Contact: {ContactNumber}, Email: {Email}";
            }
        }
    }


