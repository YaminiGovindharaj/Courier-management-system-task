﻿using CourierManagementSystemtask_day11_exception_hexa.Exceptions;
using CourierManagementSystemtask_day11_exception_hexa.Services;

namespace CourierManagementSystemtask_day11_exception_hexa
{
     class Program
    {
        static void Main(string[] args)
        { 
                CourierServices service = new CourierServices();

                try
                {
                    Console.WriteLine("Enter Tracking Number to Withdraw:");
                    string trackingNumber = Console.ReadLine();
                    Console.WriteLine("Enter Amount to Withdraw:");
                    double amount = Convert.ToDouble(Console.ReadLine());
                    service.WithdrawAmount(trackingNumber, amount);
                }
                catch (TrackingNumberNotFoundException ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Unexpected Error: {ex.Message}");
                }
                finally
                {
                    Console.WriteLine("Thank you for using the Courier Management System.");
                }

                try
                {
                    Console.WriteLine("\nEnter Employee ID to Validate:");
                    int empId = Convert.ToInt32(Console.ReadLine());
                    service.ValidateEmployee(empId);
                }
                catch (InvalidEmployeeIdexception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Unexpected Error: {ex.Message}");
                }
                finally
                {
                    Console.WriteLine("Employee validation process completed.");
                }
            }
        }
    }
