﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManagementSystemtask_day11_exception_hexa.Exceptions;
using CourierManagementSystemtask_day11_exception_hexa.Services;

namespace CourierManagementSystemtask_day11_exception_hexa.Services
{
    public class CourierServices
    {

            private Dictionary<string, double> trackingBalance = new Dictionary<string, double>
        {
            { "TN12345", 500.0 },
            { "TN67890", 1000.0 }
        };

            private List<int> employeeIds = new List<int> { 101, 102, 103 };

            // Withdraw amount based on tracking number
            public void WithdrawAmount(string trackingNumber, double amount)
            {
                if (!trackingBalance.ContainsKey(trackingNumber))
                {
                    throw new TrackingNumberNotFoundException($"Tracking number '{trackingNumber}' does not exist.");
                }

                if (trackingBalance[trackingNumber] < amount)
                {
                    throw new InvalidOperationException("Insufficient balance for withdrawal.");
                }

                trackingBalance[trackingNumber] -= amount;
                Console.WriteLine($"Withdrawal successful and the  Remaining balance: {trackingBalance[trackingNumber]}");
            }

            // Transfer amount to another tracking number
            public void TransferAmount(string fromTrackingNumber, string toTrackingNumber, double amount)
            {
                if (!trackingBalance.ContainsKey(fromTrackingNumber))
                {
                    throw new TrackingNumberNotFoundException($"Source tracking number '{fromTrackingNumber}' does not exist.");
                }

                if (!trackingBalance.ContainsKey(toTrackingNumber))
                {
                    throw new TrackingNumberNotFoundException($"Destination tracking number '{toTrackingNumber}' does not exist.");
                }

                if (trackingBalance[fromTrackingNumber] < amount)
                {
                    throw new InvalidOperationException("Insufficient balance for transfer.");
                }

                trackingBalance[fromTrackingNumber] -= amount;
                trackingBalance[toTrackingNumber] += amount;
                Console.WriteLine($"Transfer successful and the New balances: From ({trackingBalance[fromTrackingNumber]}), To ({trackingBalance[toTrackingNumber]})");
            }

            // Validate Employee ID
            public void ValidateEmployee(int employeeId)
            {
                if (!employeeIds.Contains(employeeId))
                {
                    throw new InvalidEmployeeIdexception($"Employee ID '{employeeId}' not found in the system.");
                }

                Console.WriteLine($"Employee ID '{employeeId}' is valid.");
            }
        }
    }

