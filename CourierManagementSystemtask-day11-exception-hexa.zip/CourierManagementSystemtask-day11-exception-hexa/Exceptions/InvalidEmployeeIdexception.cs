﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManagementSystemtask_day11_exception_hexa.Exceptions;

namespace CourierManagementSystemtask_day11_exception_hexa.Exceptions
{
    public class InvalidEmployeeIdexception :Exception
    {
        public InvalidEmployeeIdexception() : base("Invalid Employee ID. No such employee exists in the system.")
        { }

            public InvalidEmployeeIdexception(string message) : base(message)
        { }

            public InvalidEmployeeIdexception(string message, Exception innerException) : base(message, innerException) 
        { }
        }
    }

