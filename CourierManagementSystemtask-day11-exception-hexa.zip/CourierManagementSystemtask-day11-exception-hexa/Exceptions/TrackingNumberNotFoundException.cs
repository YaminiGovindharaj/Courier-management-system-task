﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourierManagementSystemtask_day11_exception_hexa.Exceptions
{
     public class TrackingNumberNotFoundException : Exception
        {
            public TrackingNumberNotFoundException() : base("Tracking number not found. Please enter a valid tracking number") 
        { }

            public TrackingNumberNotFoundException(string message) : base(message) { }

            public TrackingNumberNotFoundException(string message, Exception innerException) : base(message, innerException)
        { }
        }
    }

