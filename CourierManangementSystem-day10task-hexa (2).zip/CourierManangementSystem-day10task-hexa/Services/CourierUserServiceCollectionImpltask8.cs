﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;


namespace CourierManangementSystem_day10task_hexa.Services
{
    public class CourierUserServiceCollectionImpl : ICourierUserService
    {
        protected CourierCompanyCollection companyObj = new CourierCompanyCollection();

        public string PlaceOrder(Courier courier)
        {
            // to confirm that 8th task output is being excuted properly
           // Console.WriteLine(" Task 8: Placing order using CourierUserServiceCollectionImpl");
            courier.TrackingNumber = "TRK" + new Random().Next(1000, 9999);
            companyObj.Couriers.Add(courier);
            return courier.TrackingNumber;
        }

        public string GetOrderStatus(string trackingNumber)
        {
            var courier = companyObj.Couriers.Find(c => c.TrackingNumber == trackingNumber);
            return courier != null ? "In Transit" : "Not Found";
        }

        public bool CancelOrder(string trackingNumber)
        {
            var courier = companyObj.Couriers.Find(c => c.TrackingNumber == trackingNumber);
            if (courier != null)
            {
                companyObj.Couriers.Remove(courier);
                return true;
            }
            return false;
        }

        public List<Courier> GetAssignedOrders(int staffId)
        {
            return companyObj.Couriers.FindAll(c => c.AssignedEmployeeID == staffId);
        }
    }
}
