﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;
using CourierManangementSystem_day10task_hexa.Services;

namespace CourierManangementSystem_day10task_hexa.Services
{
           public class CourierAdminServiceImpl : CourierUserServiceImpl
        {
            public int AddCourierStaff(Employee employee)
            {
                companyObj.AddEmployee(employee);
                return employee.EmployeeID;
            }
        }
    }




