﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Services
{
        internal class CourierUserService : ICourierUserService
        {
            public string PlaceOrder(Courier courierObj)
            {
                
                string trackingNumber = Guid.NewGuid().ToString().Substring(0, 8);
                Console.WriteLine($"Order placed and the Tracking Number is: {trackingNumber}");
                return trackingNumber;
            }

            public string GetOrderStatus(string trackingNumber)
            {
                return "In Transit"; 
            }

            public bool CancelOrder(string trackingNumber)
            {
                return true; 
            }

            public List<Courier> GetAssignedOrders(int courierStaffId)
            {
                return new List<Courier>(); 
            }
        }
    }


