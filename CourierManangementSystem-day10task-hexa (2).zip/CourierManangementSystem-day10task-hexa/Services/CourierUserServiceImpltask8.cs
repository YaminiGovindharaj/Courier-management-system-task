﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;
using CourierManangementSystem_day10task_hexa.Services;

namespace CourierManangementSystem_day10task_hexa.Services
{
  
        public class CourierUserServiceImpl : ICourierUserService
        {
            protected CourierCompany companyObj = new CourierCompany();

            public string PlaceOrder(Courier courier)
            {
                courier.TrackingNumber = "TRK" + new Random().Next(1000, 9999);
                companyObj.AddCourier(courier);
                return courier.TrackingNumber;
            }

            public string GetOrderStatus(string trackingNumber)
            {
                var courier = companyObj.FindCourier(trackingNumber);
                return courier != null ? "In Transit" : "Not Found";
            }

            public bool CancelOrder(string trackingNumber)
            {
                return companyObj.RemoveCourier(trackingNumber);
            }

            public List<Courier> GetAssignedOrders(int staffId)
            {
                return companyObj.GetCouriersByStaff(staffId);
            }
        }
    }

