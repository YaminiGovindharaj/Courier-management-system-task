﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Entities
{
    internal class Location
    {
            public int LocationID 
        { get; set; }
            public string City 
        { get; set; }
            public string State
        { get; set; }
            public string Country 
        { get; set; }
            public string ZipCode 
        { get; set; }

            public Location() 
        { }

            public Location(int locationID, string city, string state, string country, string zipCode)
            {
                LocationID = locationID;
                City = city;
                State = state;
                Country = country;
                ZipCode = zipCode;
            }

            public override string ToString()
            {
                return $"Location ID: {LocationID}, City: {City}, State: {State}, Country: {Country}, ZipCode: {ZipCode}";
            }
        }
    }



