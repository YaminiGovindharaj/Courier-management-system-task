﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Entities
{
    internal class Payment
    {
            public int PaymentID 
        { get; set; }
            public int UserID 
        { get; set; }
            public int CourierID 
        { get; set; }
            public double Amount 
        { get; set; }
            public string PaymentMethod 
        { get; set; }
            public string Status 
        { get; set; }
            public DateTime PaymentDate
        { get; set; }

            public Payment()
        { }

            public Payment(int paymentID, int userID, int courierID, double amount, string paymentMethod, string status, DateTime paymentDate)
            {
                PaymentID = paymentID;
                UserID = userID;
                CourierID = courierID;
                Amount = amount;
                PaymentMethod = paymentMethod;
                Status = status;
                PaymentDate = paymentDate;
            }

            public override string ToString()
            {
                return $"Payment ID: {PaymentID}, User ID: {UserID}, Courier ID: {CourierID}, Amount: ${Amount}, Method: {PaymentMethod}, Status: {Status}, Date: {PaymentDate}";
            }
        }
    }

