﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Entities
{ 
        public class Employee
        {
            public int EmployeeID
        { get; set; }
            public string Name 
        { get; set; }
            public string Role 
        { get; set; }
            public string Email 
        { get; set; }
            public string ContactNumber
        { get; set; }
        public Employee() { }
        public Employee(string name, string contactNumber)
        {
            Name = name;
            ContactNumber = contactNumber;
        }


        public Employee(int employeeID, string name, string role, string email, string contactNumber)
            {
                EmployeeID = employeeID;
                Name = name;
                Role = role;
                Email = email;
                ContactNumber = contactNumber;
            }

            public override string ToString()
            {
                return $"Employee ID: {EmployeeID}, Name: {Name}, Role: {Role}, Email: {Email}, Contact: {ContactNumber}";
            }
        }
    }


