﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions
{
    internal class ShippingCostCalculator
    {
            public static double CalculateCost(double weight, string destination)
            {
                double baseRate = 5.0;
                double weightCharge = weight * 2.0; 
                double locationCharge = (destination == "International") ? 20.0 : 5.0;
            
                return baseRate + weightCharge + locationCharge;
            }
        }
    }
