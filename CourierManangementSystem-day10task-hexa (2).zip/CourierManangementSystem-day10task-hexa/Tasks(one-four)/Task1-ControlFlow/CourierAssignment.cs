﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow
{
    internal class CourierAssignment
        {
            public static void AssignCourier(List<string> couriers, string newOrder)
            {
                foreach (var courier in couriers)
                {
                    Console.WriteLine($"Assigning order '{newOrder}' to courier: {courier}");
                    return;
                }
                Console.WriteLine("No couriers available");
            }
        }
    }

