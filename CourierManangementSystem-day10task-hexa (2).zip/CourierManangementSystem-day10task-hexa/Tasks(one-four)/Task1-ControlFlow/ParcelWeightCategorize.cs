﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow

// i have categorized Parcel Based on Weight so we can use switch-case 
{
    internal class ParcelWeightCategorize
    {
            public static void CategorizeParcel(double weight)
            {
                switch (weight)
                {
                    case < 5:
                        Console.WriteLine("Category: Light Parcel");
                        break;
                    case < 20:
                        Console.WriteLine("Category: Medium Parcel");
                        break;
                    default:
                        Console.WriteLine("Category: Heavy Parcel");
                        break;
                }
            }
        }
    }

