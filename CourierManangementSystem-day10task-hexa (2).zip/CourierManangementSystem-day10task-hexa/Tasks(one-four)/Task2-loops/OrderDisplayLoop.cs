﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task2_loops;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task2_loops
    
{
    internal class OrderDisplayLoop
    {
        public static void ShowOrders(List<string> orders)
            {
                if (orders.Count == 0)
                {
                    Console.WriteLine("No orders to display.");
                    return;
                }

                Console.WriteLine("List of Orders:");
                for (int i = 0; i < orders.Count; i++) 
                {
                    Console.WriteLine($"{i + 1}. {orders[i]}");
                }
            }
        }
    }


