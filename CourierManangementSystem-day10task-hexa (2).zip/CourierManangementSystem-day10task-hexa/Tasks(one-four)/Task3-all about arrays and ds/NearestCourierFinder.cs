﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds
{
    internal class NearestCourierFinder
    {
            public static void FindNearestCourier()
            {
                string[] couriers = { "Courier A (2 km)", "Courier B (5 km)", "Courier C (3 km)", "Courier D (7 km)" };
                int[] distances = { 2, 5, 3, 7 }; 

                int minIndex = 0;
            // to find the courier with the least distance
                for (int i = 1; i < distances.Length; i++) 
                {
                    if (distances[i] < distances[minIndex])
                    {
                        minIndex = i;
                    }
                }

                Console.WriteLine($"\nNearest Available Courier: {couriers[minIndex]}");
            }
        }
    }
