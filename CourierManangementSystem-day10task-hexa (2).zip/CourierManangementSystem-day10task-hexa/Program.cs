﻿using CourierManangementSystem_day10task_hexa.Services;

namespace CourierManangementSystem_day10task_hexa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //everything calls from Ui menu , being the entry point 
    
            UserInterface.Start();
        }
    }
}
