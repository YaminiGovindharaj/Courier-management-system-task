﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using CourierManangementSystem_day10task_hexa.Entities;

namespace CourierManangementSystem_day10task_hexa.Entities
{
   // for collection task
        public class CourierCompanyCollection
        {
            public List<Courier> Couriers { get; set; } = new List<Courier>();
            public List<Employee> Employees { get; set; } = new List<Employee>();
        }
    }
   
