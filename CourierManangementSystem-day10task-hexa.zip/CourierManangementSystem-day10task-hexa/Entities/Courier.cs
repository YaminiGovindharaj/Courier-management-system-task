﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;


namespace CourierManangementSystem_day10task_hexa.Entities
{
    public class Courier
    {
        //id,sendername, receiver name, both address, weight, trackingno, shipmentdate,status,employeeid
            public int CourierId { get; set; }
            public string SenderName { get; set; }
            public string SenderAddress { get; set; }
            public string ReceiverName { get; set; }
            public string ReceiverAddress { get; set; }
            public double Weight { get; set; }
            public string TrackingNumber { get; set; }
            public DateTime ShipmentDate { get; set; }
            public int Status { get; set; }
          
            public int AssignedEmployeeID { get; set; }

             public Courier() { }

            public Courier(int courierId, string senderName, string senderAddress,
                string receiverName, string receiverAddress, double weight,
                string trackingNumber, DateTime shipmentDate, int status)
            {
                CourierId = courierId;
                SenderName = senderName;
                SenderAddress = senderAddress;
                ReceiverName = receiverName;
                ReceiverAddress = receiverAddress;
                Weight = weight;
                TrackingNumber = trackingNumber;
                ShipmentDate = shipmentDate;
               
            }
        public override string ToString()
        {
            return $"Tracking Number: {TrackingNumber}, Sender: {SenderName}, Receiver: {ReceiverName}";
        }

    }
    }

    
