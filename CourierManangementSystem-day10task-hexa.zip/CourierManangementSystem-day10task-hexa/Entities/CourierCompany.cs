﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;


namespace CourierManangementSystem_day10task_hexa.Entities
{
    public class CourierCompany
    {
        public int CompanyID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactNumber { get; set; }
        public string Email { get; set; }

      //collection task
        public List<Employee> Employees { get; set; } = new List<Employee>();
        public List<Courier> Couriers { get; set; } = new List<Courier>();

        public CourierCompany() { }

        public CourierCompany(int companyID, string name, string address, string contactNumber, string email)
        {
            CompanyID = companyID;
            Name = name;
            Address = address;
            ContactNumber = contactNumber;
            Email = email;
        }

        public void AddEmployee(Employee employee)
        {
            Employees.Add(employee);
        }

     
        public bool RemoveEmployee(int employeeId)
        {
            var emp = Employees.Find(e => e.EmployeeID == employeeId);
            if (emp != null)
            {
                Employees.Remove(emp);
                return true;
            }
            return false;
        }

        public List<Employee> GetAllEmployees()
        {
            return Employees;
        }

        public override string ToString()
        {
            return $"Company ID: {CompanyID}, Name: {Name}, Address: {Address}, Contact: {ContactNumber}, Email: {Email}";
        }



        //for task 8 am updating 

        public void AddCourier(Courier courier)
        {
            Couriers.Add(courier);
        }

        public Courier FindCourier(string trackingNumber)
        {
            return Couriers.Find(c => c.TrackingNumber == trackingNumber);
        }

        public bool RemoveCourier(string trackingNumber)
        {
            var courier = Couriers.Find(c => c.TrackingNumber == trackingNumber);
            if (courier != null)
            {
                Couriers.Remove(courier);
                return true;
            }
            return false;
        }

        public List<Courier> GetCouriersByStaff(int staffId)
        {
            return Couriers.FindAll(c => c.AssignedEmployeeID == staffId);
        }
    }
}
    

