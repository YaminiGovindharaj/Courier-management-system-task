﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Entities;
using CourierManangementSystem_day10task_hexa.Services;

namespace CourierManangementSystem_day10task_hexa.Services
{
    //to implement the collection task
    public class CourierAdminServiceCollectionImpl : CourierUserServiceCollectionImpl, ICourierAdminService
    {
        public int AddCourierStaff(Employee employee)
        {
            employee.EmployeeID = new Random().Next(100, 999); 

            companyObj.Employees.Add(employee);
            return employee.EmployeeID;
        }

        public bool RemoveCourierStaff(int staffId)
        {
            Employee staff = companyObj.Employees.Find(e => e.EmployeeID == staffId);
            if (staff != null)
            {
                companyObj.Employees.Remove(staff);
                return true;
            }
            return false;
        }

        public List<Employee> GetAllCourierStaff()
        {
            return companyObj.Employees;
        }
    }
}
