﻿using System;
using System.Collections.Generic;
using CourierManangementSystem_day10task_hexa.Dao_task9_;
using CourierManangementSystem_day10task_hexa.Entities;
using CourierManangementSystem_day10task_hexa.Exceptions_task7;
using CourierManangementSystem_day10task_hexa.Services;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;
using CourierManangementSystem_day10task_hexa.Enum;

namespace CourierManangementSystem_day10task_hexa
{
    internal class UserInterface
    {
        static ICourierUserService userService = new CourierUserServiceCollectionImpl();
        static ICourierAdminService adminService = new CourierAdminServiceCollectionImpl();

        public static void Start()
        {
            while (true)
            {
                Console.WriteLine("-- Courier Management System ---");
                Console.WriteLine("1. Place Order");
                Console.WriteLine("2. Get Order Status");
                Console.WriteLine("3. Cancel Order");
                Console.WriteLine("4. View Assigned Orders");
                Console.WriteLine("5. Add Courier Staff");
                Console.WriteLine("6. Assign Couriers to Shipping");
                Console.WriteLine("7. Parcel Tracking");
                Console.WriteLine("8. Validate Customer Data");
                Console.WriteLine("9. Format Address");
                Console.WriteLine("10. Generate Order Confirmation Email");
                Console.WriteLine("11. Calculate Shipping Cost");
                Console.WriteLine("12. Generate Secure Password");
                Console.WriteLine("13. Find Similar Addresses");
                Console.WriteLine("14. Simulate Error Scenarios");
                Console.WriteLine("15. Insert Order into DB");
                Console.WriteLine("16. Update Courier Status in DB");
                Console.WriteLine("17. View Delivery History from DB");
                Console.WriteLine("18. Generate Shipment Status Report");
                Console.WriteLine("19. Generate Revenue Report");
               
                Console.WriteLine("20. Exit");
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine();
                Console.WriteLine();

                switch (choice)
                {
                    case "1": PlaceOrder(); break;
                    case "2": GetOrderStatus(); break;
                    case "3": CancelOrder(); break;
                    case "4": GetAssignedOrders(); break;
                    case "5": AddCourierStaff(); break;
                    case "6": AssignCouriersToShipments(); break;
                    case "7": ParcelTracking(); break;
                    case "8": ValidateCustomerData(); break;
                    case "9": FormatAddress(); break;
                    case "10": GenerateOrderConfirmation(); break;
                    case "11": CalculateShippingCost(); break;
                    case "12": GenerateSecurePassword(); break;
                    case "13": FindSimilarAddresses(); break;
                    case "14": SimulateErrorScenarios(); break;
                    case "15": InsertOrderToDb(); break;
                    case "16": UpdateCourierStatus(); break;
                    case "17": ShowDeliveryHistory(); break;
                    case "18": ShowShipmentStatusReport(); break;
                    case "19": ShowRevenueReport(); break;
                    

                    case "20":
                        Console.WriteLine("Exiting  the courier application...");
                        return;

                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }

                Console.WriteLine("\nPress Enter to continue...");
                Console.ReadLine();
            }
        }

        static void PlaceOrder()
        {
            Console.Write("Sender Name: ");
            string senderName = Console.ReadLine();
            Console.Write("Sender Address: ");
            string senderAddress = Console.ReadLine();
            Console.Write("Receiver Name: ");
            string receiverName = Console.ReadLine();
            Console.Write("Receiver Address: ");
            string receiverAddress = Console.ReadLine();
            Console.Write("Package Weight: ");
            double weight = Convert.ToDouble(Console.ReadLine());

            Courier courier = new Courier(0, senderName, senderAddress, receiverName, receiverAddress, weight, "", DateTime.Now, 1);
            string trackingNumber = userService.PlaceOrder(courier);
            Console.WriteLine($"Order placed. Tracking Number: {trackingNumber}");
        }

        static void GetOrderStatus()
        {
            Console.Write("Enter tracking number: ");
            string tracking = Console.ReadLine();
            string status = userService.GetOrderStatus(tracking);
            Console.WriteLine($"Status: {status}");
        }

        static void CancelOrder()
        {
            Console.Write("Enter tracking number: ");
            string tracking = Console.ReadLine();
            bool result = userService.CancelOrder(tracking);
            Console.WriteLine(result ? "Cancelled successfully." : "Order not found.");
        }

        static void GetAssignedOrders()
        {
            Console.Write("Enter Staff ID: ");
            int id = Convert.ToInt32(Console.ReadLine());

            List<Courier> orders = userService.GetAssignedOrders(id);

            if (orders.Count == 0)
            {
                Console.WriteLine("No orders assigned to this staff member.");
                return;
            }

            Console.WriteLine("\nAssigned Orders:");
            Console.WriteLine("----------------------------");
            Console.WriteLine("Tracking | Sender | Receiver | Status");
            Console.WriteLine("------------------------");

            foreach (var c in orders)
            {
                Console.WriteLine($"{c.TrackingNumber} | {c.SenderName} | {c.ReceiverName} | {c.Status}");
            }

            Console.WriteLine("---------------------");
        }


        static void AddCourierStaff()
        {
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();
            Console.Write("Contact Number: ");
            string contact = Console.ReadLine();
            Employee emp = new Employee(name, contact);
            int id = adminService.AddCourierStaff(emp);
            Console.WriteLine($"Added successfully with ID: {id}");
        }

        static void AssignCouriersToShipments() => CourierAssignment.AssignCourier(new List<string> { "Courier1", "Courier2" }, "Order123");

        static void ParcelTracking() => ParcelTrackingHistory.ShowTrackingHistory();

        static void ValidateCustomerData()
        {
            Console.Write("Name: "); string name = Console.ReadLine();
            Console.Write("Address: "); string address = Console.ReadLine();
            Console.Write("Phone: "); string phone = Console.ReadLine();
            Console.WriteLine(CustomerValidation.Validate(name, address, phone) ? "Valid" : "Invalid");
        }

        static void FormatAddress()
        {
            Console.Write("Enter full address: ");
            string input = Console.ReadLine();
            Console.WriteLine(AddressFormatting.Format(input));
        }

        static void GenerateOrderConfirmation() => OrderConfirmation.GenerateEmail();

        static void CalculateShippingCost()
        {
            Console.Write("Weight: "); double weight = Convert.ToDouble(Console.ReadLine());
            Console.Write("Destination: "); string dest = Console.ReadLine();
            Console.WriteLine($"Cost: {ShippingCostCalculator.CalculateCost(weight, dest)}");
        }

        static void GenerateSecurePassword() => Console.WriteLine($"Password: {PasswordGenerator.GeneratePassword(10)}");

        static void FindSimilarAddresses()
        {
            Console.Write("First Address: "); string a = Console.ReadLine();
            Console.Write("Second Address: "); string b = Console.ReadLine();
            Console.WriteLine(FindSimilarAddress.AreAddressesSimilar(a, b) ? "Similar" : "Different");
        }

        static void SimulateErrorScenarios()
        {
            try
            {
                Console.Write("Tracking Number: ");
                ExceptionHandler.SimulateTrackingError(Console.ReadLine());
            }
            catch (TrackingNumberNotFoundException e)
            {
                Console.WriteLine("Tracking Error: " + e.Message);
            }

            try
            {
                Console.Write("Employee ID: ");
                ExceptionHandler.SimulateEmployeeIdCheck(Convert.ToInt32(Console.ReadLine()));
            }
            catch (InvalidEmployeeIdException e)
            {
                Console.WriteLine("Employee Error: " + e.Message);
            }
        }

        static void InsertOrderToDb()
        {
            Console.WriteLine("Enter Courier Details");

            Console.Write("Sender Name: ");
            string senderName = Console.ReadLine();

            Console.Write("Sender Address: ");
            string senderAddress = Console.ReadLine();

            Console.Write("Receiver Name: ");
            string receiverName = Console.ReadLine();

            Console.Write("Receiver Address: ");
            string receiverAddress = Console.ReadLine();

            Console.Write("Weight (in kg): ");
            double weight = double.Parse(Console.ReadLine());

            Console.Write("Assigned Employee ID: ");
            int assignedEmployeeId = int.Parse(Console.ReadLine());

            string trackingNumber = "TRK" + new Random().Next(1000, 9999);

            Courier courier = new Courier(
                0,
                senderName,
                senderAddress,
                receiverName,
                receiverAddress,
                weight,
                trackingNumber,
                DateTime.Now,
                1
            );
            courier.AssignedEmployeeID = assignedEmployeeId;

            CourierServiceDb.InsertOrder(courier);

            // Display the inserted order
            Console.WriteLine("\nCourier inserted successfully  Details:");
            Console.WriteLine($"Tracking #: {courier.TrackingNumber}");
            Console.WriteLine($"Sender: {courier.SenderName}, Address: {courier.SenderAddress}");
            Console.WriteLine($"Receiver: {courier.ReceiverName}, Address: {courier.ReceiverAddress}");
            Console.WriteLine($"Weight: {courier.Weight}kg, Assigned Staff ID: {courier.AssignedEmployeeID}");
        }


        static void UpdateCourierStatus()
        {
            try
            {
                Console.WriteLine(" Update Courier Status ");

                Console.Write("Enter Tracking Number: ");
                string trackingNumber = Console.ReadLine();

                Console.WriteLine("Choose new status:");
                Console.WriteLine("0 - Yet to Transit");
                Console.WriteLine("1 - In Transit");
                Console.WriteLine("2 - Delivered");
                Console.Write("Enter new status code: ");

                bool validStatus = int.TryParse(Console.ReadLine(), out int newStatus);

                if (!validStatus || newStatus < 0 || newStatus > 2)
                {
                    Console.WriteLine(" Invalid status code. Please enter 0, 1, or 2.");
                    return;
                }

                bool updated = CourierServiceDb.UpdateCourierStatus(trackingNumber, newStatus);

                if (updated)
                {
                    Console.WriteLine($" Status for tracking number '{trackingNumber}' updated to: {(CourierStatus)newStatus}");
                }
                else
                {
                    Console.WriteLine(" Update failed. No record found with the provided tracking number.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Error occurred while updating status: {ex.Message}");
            }
        }





        static void ShowDeliveryHistory()
        {
            Console.Write("Enter Tracking Number: ");
            string trackingNumber = Console.ReadLine();
            CourierServiceDb.GetDeliveryHistory(trackingNumber);
        }

        static void ShowShipmentStatusReport()
        {
            CourierServiceDb.GenerateShipmentReport();
        }

        static void ShowRevenueReport() => CourierServiceDb.GenerateRevenueReport();
    }
}
