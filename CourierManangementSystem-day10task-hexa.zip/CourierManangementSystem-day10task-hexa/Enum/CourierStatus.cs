﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourierManangementSystem_day10task_hexa.Enum
{
        public enum CourierStatus
        {
            YetToTransit = 0,
            InTransit = 1,
            Delivered = 2
        }
    }
