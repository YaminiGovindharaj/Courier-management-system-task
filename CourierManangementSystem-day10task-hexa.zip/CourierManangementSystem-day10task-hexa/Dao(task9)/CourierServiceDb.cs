﻿using System;
using System.Data.SqlClient;
using CourierManangementSystem_day10task_hexa.Entities;
using CourierManangementSystem_day10task_hexa.ConnectionUtil_task9_;

namespace CourierManangementSystem_day10task_hexa.Dao_task9_
{
    public class CourierServiceDb
    {
        private static SqlConnection connection;

        static CourierServiceDb()
        {
            connection = DBConnection.GetConnection();
        }

        public static void InsertOrder(Courier courier)
        {
            string query = @"INSERT INTO Couriers 
                    (SenderName, SenderAddress, ReceiverName, ReceiverAddress, Weight, TrackingNumber, ShipmentDate, Status, AssignedEmployeeID)
                     VALUES 
                    (@SenderName, @SenderAddress, @ReceiverName, @ReceiverAddress, @Weight, @TrackingNumber, @ShipmentDate, @Status, @AssignedEmployeeID)";

            using SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@SenderName", courier.SenderName);
            cmd.Parameters.AddWithValue("@SenderAddress", courier.SenderAddress);
            cmd.Parameters.AddWithValue("@ReceiverName", courier.ReceiverName);
            cmd.Parameters.AddWithValue("@ReceiverAddress", courier.ReceiverAddress);
            cmd.Parameters.AddWithValue("@Weight", courier.Weight);
            cmd.Parameters.AddWithValue("@TrackingNumber", courier.TrackingNumber);
            cmd.Parameters.AddWithValue("@ShipmentDate", courier.ShipmentDate);
            cmd.Parameters.AddWithValue("@Status", courier.Status);
            cmd.Parameters.AddWithValue("@AssignedEmployeeID", courier.AssignedEmployeeID);

            int result = cmd.ExecuteNonQuery();
            Console.WriteLine(result > 0 ? "\nInserted successfully into database." : "\nInsert failed.");
        }


        public static bool UpdateCourierStatus(string trackingNumber, int newStatus)
        {
            string query = "UPDATE Couriers SET Status = @Status WHERE TrackingNumber = @TrackingNumber";

            using SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@Status", newStatus);
            cmd.Parameters.AddWithValue("@TrackingNumber", trackingNumber);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0;
        }

        public static void GetDeliveryHistory(string trackingNumber)
        {
            string query = "SELECT * FROM Couriers WHERE TrackingNumber = @TrackingNumber";
            using SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@TrackingNumber", trackingNumber);
            using SqlDataReader reader = cmd.ExecuteReader();

            if (!reader.HasRows)
            {
                Console.WriteLine("No delivery history found.");
                return;
            }

            while (reader.Read())
            {
                Console.WriteLine($"Tracking: {reader["TrackingNumber"]}, Status: {reader["Status"]}, Date: {reader["ShipmentDate"]}");
            }
        }


        public static void GenerateShipmentReport()
        {
            string query = "SELECT Status, COUNT(*) AS Total FROM Couriers GROUP BY Status";
            using SqlCommand cmd = new SqlCommand(query, connection);
            using SqlDataReader reader = cmd.ExecuteReader();

            Console.WriteLine("Shipment Status Report:");
            while (reader.Read())
            {
                Console.WriteLine($"Status: {reader["Status"]} | Total: {reader["Total"]}");
            }
        }




        
        public static void GenerateRevenueReport()
        {
            string query = "SELECT SUM(Amount) AS TotalRevenue FROM Payments";
            using SqlCommand cmd = new SqlCommand(query, connection);
            var result = cmd.ExecuteScalar();
            Console.WriteLine($"Total Revenue: Rs. {result ?? 0}");
        }
    }
}
