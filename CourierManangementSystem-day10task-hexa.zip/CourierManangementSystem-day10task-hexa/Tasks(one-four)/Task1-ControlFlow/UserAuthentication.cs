﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow;


namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task1_ControlFlow
{
    internal class UserAuthentication
    {
            private static Dictionary<string, string> users = new Dictionary<string, string>
        {
            { "admin", "admin123" },
            { "customer1yamini", "passyamini123" },
            { "employee1Nirosha", "empnirosha456" }
        };

            public static bool Login(string username, string password)
            {
                if (users.ContainsKey(username) && users[username] == password)
                {
                    Console.WriteLine("Login successful");
                    return true;
                }
                else
                {
                    Console.WriteLine("Invalid username or password.");
                    return false;
                }
            }
        }
    }

