﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions
{
    internal class ParcelTrackingSimulation
    {
            public static string GenerateTrackingID(string sender, string receiver)
            {
                if (sender.Length < 2 || receiver.Length < 2)
                    return "Invalid Names for Tracking ID";

                string senderPart = sender.Substring(0, 2).ToUpper();
                string receiverPart = receiver.Substring(0, 2).ToUpper();
                string timePart = DateTime.Now.ToString("MMddHHmmss");

                return $"{senderPart}{receiverPart}{timePart}";
            }
        }
    }

