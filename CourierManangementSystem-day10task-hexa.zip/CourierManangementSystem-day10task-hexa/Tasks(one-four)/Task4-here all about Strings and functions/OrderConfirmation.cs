﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions
{

    internal class OrderConfirmation
    {
       
            private static Dictionary<int, string> orders = new Dictionary<int, string>();

            public static void AddOrder(int orderId, string details)
            {
                orders[orderId] = details;
                Console.WriteLine($"Order {orderId} added.");
            }

            public static void GetOrder(int orderId)
            {
                if (orders.ContainsKey(orderId))
                    Console.WriteLine($"Order {orderId}: {orders[orderId]}");
                else
                    Console.WriteLine($"Order {orderId} not found.");
            }
        public static void GenerateEmail()
        {
            Console.Write("Enter Customer Name: ");
            string customerName = Console.ReadLine();

            Console.Write("Enter Order Tracking Number: ");
            string trackingNumber = Console.ReadLine();

            Console.Write("Enter Delivery Address: ");
            string deliveryAddress = Console.ReadLine();

            Console.Write("Enter Expected Delivery Date (yyyy-mm-dd): ");
            string deliveryDate = Console.ReadLine();

            Console.WriteLine("Order Confirmation Email");
            Console.WriteLine($"To: {customerName}");
            Console.WriteLine("Subject: Your Order Confirmation - " + trackingNumber);
            Console.WriteLine($"Dear {customerName},");
            Console.WriteLine();
            Console.WriteLine("Thank you for placing your order with Courier Management System!");
            Console.WriteLine($"Your order with tracking number **{trackingNumber} has been successfully received.");
            Console.WriteLine($"It will be delivered to {deliveryAddress}on or before {deliveryDate}.");
            Console.WriteLine("Best regards,");
           
        }
    }
    }


