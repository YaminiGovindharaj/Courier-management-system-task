﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task4_here_all_about_Strings_and_functions
{
    internal class FindSimilarAddress
    {
            public static bool AreAddressesSimilar(string addr1, string addr2)
            {
                return addr1.Trim().ToLower().Equals(addr2.Trim().ToLower());
            }
        }
    }
