﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds
{
    internal class ParcelTrackingHistory
        {
            public static void ShowTrackingHistory()
            {
                string[] history = {
                "Dispatched ",
                "Arrived ",
                "Out for Delivery",
                "Delivered to Customer"
            };

                Console.WriteLine("\nTracking History of the Parcel:");
            // array concept is implemented to store the tracking details
                for (int i = 0; i < history.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {history[i]}");
                }
            }
        }
    }

