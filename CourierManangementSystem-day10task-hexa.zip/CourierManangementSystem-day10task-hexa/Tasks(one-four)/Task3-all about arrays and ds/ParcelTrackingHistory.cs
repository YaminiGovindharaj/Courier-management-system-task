﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds;

namespace CourierManangementSystem_day10task_hexa.Tasks_one_four_.Task3_all_about_arrays_and_ds
{

        internal class ParcelTrackingHistory
        {
            public static void ShowTrackingHistory()
            {
              
                Dictionary<string, string[]> trackingData = new Dictionary<string, string[]>
            {
                { "TRK1234", new string[] { "Dispatched", "Arrived at Hub", "Out for Delivery", "Delivered" } },
                { "TRK5678", new string[] { "Dispatched", "In Transit", "Arrived at Destination" } },
                { "TRK9999", new string[] { "Dispatched", "On Hold" } }
            };

                Console.Write("Enter Tracking Number: ");
                string trackingNumber = Console.ReadLine().Trim();

                if (trackingData.ContainsKey(trackingNumber))
                {
                    Console.WriteLine($"\nTracking History for {trackingNumber}:");
                    string[] history = trackingData[trackingNumber];
                    for (int i = 0; i < history.Length; i++)
                    {
                        Console.WriteLine($"{i + 1}. {history[i]}");
                    }
                }
                else
                {
                    Console.WriteLine("Tracking number not found in the system.");
                }
            }
        }
    }

