﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CourierManangementSystem_day10task_hexa.ConnectionUtil_task9_
{


        public class DBConnection
        {
            private static readonly string connectionString = @"Server=LAPTOP-5I9PJH1D\SQLEXPRESS; Database=CourierDBtask9; Integrated Security=True;";

            public static SqlConnection GetConnection()
            {
                SqlConnection conn = new SqlConnection(connectionString);
                try
                {
                    conn.Open();
                    return conn;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Connection failed: " + ex.Message);
                    return null;
                }
            }

            public static void CloseConnection(SqlConnection conn)
            {
                if (conn != null && conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                    conn.Dispose();
                    Console.WriteLine("Connection closed.");
                }
            }
        }
    }

