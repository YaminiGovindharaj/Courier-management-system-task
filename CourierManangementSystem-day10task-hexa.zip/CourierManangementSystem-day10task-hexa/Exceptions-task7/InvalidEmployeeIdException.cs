﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Exceptions_task7;

namespace CourierManangementSystem_day10task_hexa.Exceptions_task7
{
    //exception task
    public class InvalidEmployeeIdException : Exception
    {
         public InvalidEmployeeIdException(string message) : base(message)
            {
            }
        }
    }

