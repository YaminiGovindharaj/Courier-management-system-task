﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourierManangementSystem_day10task_hexa.Exceptions_task7;


namespace CourierManangementSystem_day10task_hexa.Exceptions_task7
{
    //exception task
    public class ExceptionHandler
    {
    public static void SimulateTrackingError(string trackingNumber)
            {
                if (string.IsNullOrEmpty(trackingNumber) || trackingNumber != "ABC123")
                {
                    throw new TrackingNumberNotFoundException("Tracking number not found.");
                }
            }

            public static void SimulateEmployeeIdCheck(int employeeId)
            {
                if (employeeId <= 0 || employeeId != 101)
                {
                    throw new InvalidEmployeeIdException("Employee ID is invalid or does not exist.");
                }
            }
        }
    }

